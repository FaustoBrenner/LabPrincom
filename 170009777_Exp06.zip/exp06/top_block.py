#!/usr/bin/env python2
# -*- coding: utf-8 -*-
##################################################
# GNU Radio Python Flow Graph
# Title: Top Block
# Generated: Fri Oct 23 17:25:56 2020
##################################################

if __name__ == '__main__':
    import ctypes
    import sys
    if sys.platform.startswith('linux'):
        try:
            x11 = ctypes.cdll.LoadLibrary('libX11.so')
            x11.XInitThreads()
        except:
            print "Warning: failed to XInitThreads()"

from PyQt4 import Qt
from gnuradio import analog
from gnuradio import blocks
from gnuradio import eng_notation
from gnuradio import filter
from gnuradio import gr
from gnuradio import qtgui
from gnuradio.eng_option import eng_option
from gnuradio.filter import firdes
from gnuradio.qtgui import Range, RangeWidget
from optparse import OptionParser
import sip
import sys


class top_block(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "Top Block")
        Qt.QWidget.__init__(self)
        self.setWindowTitle("Top Block")
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except:
            pass
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("GNU Radio", "top_block")
        self.restoreGeometry(self.settings.value("geometry").toByteArray())

        ##################################################
        # Variables
        ##################################################
        self.kf = kf = 8000
        self.Am = Am = 0.5
        self.samp_rate = samp_rate = 200000
        self.output_gain = output_gain = 2
        self.fm = fm = 500
        self.fc = fc = 50000
        self.Df = Df = kf*Am
        self.Bm = Bm = 10000
        self.An_FM = An_FM = 0
        self.An_AM = An_AM = 0

        ##################################################
        # Blocks
        ##################################################
        self._output_gain_range = Range(1, 4, .01, 2, 200)
        self._output_gain_win = RangeWidget(self._output_gain_range, self.set_output_gain, "output_gain", "counter_slider", float)
        self.top_layout.addWidget(self._output_gain_win)
        self.aba = Qt.QTabWidget()
        self.aba_widget_0 = Qt.QWidget()
        self.aba_layout_0 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.aba_widget_0)
        self.aba_grid_layout_0 = Qt.QGridLayout()
        self.aba_layout_0.addLayout(self.aba_grid_layout_0)
        self.aba.addTab(self.aba_widget_0, "Sinais no Tempo")
        self.aba_widget_1 = Qt.QWidget()
        self.aba_layout_1 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.aba_widget_1)
        self.aba_grid_layout_1 = Qt.QGridLayout()
        self.aba_layout_1.addLayout(self.aba_grid_layout_1)
        self.aba.addTab(self.aba_widget_1, "Potencias")
        self.aba_widget_2 = Qt.QWidget()
        self.aba_layout_2 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.aba_widget_2)
        self.aba_grid_layout_2 = Qt.QGridLayout()
        self.aba_layout_2.addLayout(self.aba_grid_layout_2)
        self.aba.addTab(self.aba_widget_2, "SNR")
        self.aba_widget_3 = Qt.QWidget()
        self.aba_layout_3 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.aba_widget_3)
        self.aba_grid_layout_3 = Qt.QGridLayout()
        self.aba_layout_3.addLayout(self.aba_grid_layout_3)
        self.aba.addTab(self.aba_widget_3, "SNR - Constellation")
        self.aba_widget_4 = Qt.QWidget()
        self.aba_layout_4 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.aba_widget_4)
        self.aba_grid_layout_4 = Qt.QGridLayout()
        self.aba_layout_4.addLayout(self.aba_grid_layout_4)
        self.aba.addTab(self.aba_widget_4, "Pot")
        self.top_layout.addWidget(self.aba)
        self._An_FM_range = Range(0, 2, 0.01, 0, 200)
        self._An_FM_win = RangeWidget(self._An_FM_range, self.set_An_FM, "An_FM", "counter_slider", float)
        self.top_layout.addWidget(self._An_FM_win)
        self._An_AM_range = Range(0, 2, 0.01, 0, 200)
        self._An_AM_win = RangeWidget(self._An_AM_range, self.set_An_AM, "An_AM", "counter_slider", float)
        self.top_layout.addWidget(self._An_AM_win)
        self._Am_range = Range(0, 1, .01, 0.5, 200)
        self._Am_win = RangeWidget(self._Am_range, self.set_Am, "Am", "counter_slider", float)
        self.top_layout.addWidget(self._Am_win)
        self.qtgui_time_sink_x_1_0 = qtgui.time_sink_f(
        	1024, #size
        	samp_rate, #samp_rate
        	"RSR IN", #name
        	2 #number of inputs
        )
        self.qtgui_time_sink_x_1_0.set_update_time(0.10)
        self.qtgui_time_sink_x_1_0.set_y_axis(-1, 1)
        
        self.qtgui_time_sink_x_1_0.set_y_label("Amplitude", "")
        
        self.qtgui_time_sink_x_1_0.enable_tags(-1, True)
        self.qtgui_time_sink_x_1_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_1_0.enable_autoscale(False)
        self.qtgui_time_sink_x_1_0.enable_grid(False)
        self.qtgui_time_sink_x_1_0.enable_control_panel(False)
        
        if not True:
          self.qtgui_time_sink_x_1_0.disable_legend()
        
        labels = ["DSB", "FM", "", "", "",
                  "", "", "", "", ""]
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        
        for i in xrange(2):
            if len(labels[i]) == 0:
                self.qtgui_time_sink_x_1_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_time_sink_x_1_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_1_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_1_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_1_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_1_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_1_0.set_line_alpha(i, alphas[i])
        
        self._qtgui_time_sink_x_1_0_win = sip.wrapinstance(self.qtgui_time_sink_x_1_0.pyqwidget(), Qt.QWidget)
        self.aba_layout_2.addWidget(self._qtgui_time_sink_x_1_0_win)
        self.qtgui_time_sink_x_1 = qtgui.time_sink_f(
        	1024, #size
        	samp_rate, #samp_rate
        	"RSR OUT", #name
        	2 #number of inputs
        )
        self.qtgui_time_sink_x_1.set_update_time(0.10)
        self.qtgui_time_sink_x_1.set_y_axis(-1, 1)
        
        self.qtgui_time_sink_x_1.set_y_label("Amplitude", "")
        
        self.qtgui_time_sink_x_1.enable_tags(-1, True)
        self.qtgui_time_sink_x_1.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_1.enable_autoscale(False)
        self.qtgui_time_sink_x_1.enable_grid(False)
        self.qtgui_time_sink_x_1.enable_control_panel(False)
        
        if not True:
          self.qtgui_time_sink_x_1.disable_legend()
        
        labels = ["DSB", "FM", "", "", "",
                  "", "", "", "", ""]
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        
        for i in xrange(2):
            if len(labels[i]) == 0:
                self.qtgui_time_sink_x_1.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_time_sink_x_1.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_1.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_1.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_1.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_1.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_1.set_line_alpha(i, alphas[i])
        
        self._qtgui_time_sink_x_1_win = sip.wrapinstance(self.qtgui_time_sink_x_1.pyqwidget(), Qt.QWidget)
        self.aba_layout_2.addWidget(self._qtgui_time_sink_x_1_win)
        self.qtgui_time_sink_x_0 = qtgui.time_sink_f(
        	1024, #size
        	samp_rate, #samp_rate
        	"DEMODS", #name
        	3 #number of inputs
        )
        self.qtgui_time_sink_x_0.set_update_time(0.10)
        self.qtgui_time_sink_x_0.set_y_axis(-1, 1)
        
        self.qtgui_time_sink_x_0.set_y_label("Amplitude", "")
        
        self.qtgui_time_sink_x_0.enable_tags(-1, True)
        self.qtgui_time_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_0.enable_autoscale(False)
        self.qtgui_time_sink_x_0.enable_grid(False)
        self.qtgui_time_sink_x_0.enable_control_panel(False)
        
        if not True:
          self.qtgui_time_sink_x_0.disable_legend()
        
        labels = ["DSB", "FM", "mensagem", "", "",
                  "", "", "", "", ""]
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        
        for i in xrange(3):
            if len(labels[i]) == 0:
                self.qtgui_time_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_time_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_0.set_line_alpha(i, alphas[i])
        
        self._qtgui_time_sink_x_0_win = sip.wrapinstance(self.qtgui_time_sink_x_0.pyqwidget(), Qt.QWidget)
        self.aba_layout_0.addWidget(self._qtgui_time_sink_x_0_win)
        self.qtgui_number_sink_0 = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_HORIZ,
            2
        )
        self.qtgui_number_sink_0.set_update_time(0.10)
        self.qtgui_number_sink_0.set_title("Pot_ruido_OUT")
        
        labels = ["DSB", "FM", "", "", "",
                  "", "", "", "", ""]
        units = ["", "", "", "", "",
                 "", "", "", "", ""]
        colors = [("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"),
                  ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        for i in xrange(2):
            self.qtgui_number_sink_0.set_min(i, -1)
            self.qtgui_number_sink_0.set_max(i, 1)
            self.qtgui_number_sink_0.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.qtgui_number_sink_0.set_label(i, "Data {0}".format(i))
            else:
                self.qtgui_number_sink_0.set_label(i, labels[i])
            self.qtgui_number_sink_0.set_unit(i, units[i])
            self.qtgui_number_sink_0.set_factor(i, factor[i])
        
        self.qtgui_number_sink_0.enable_autoscale(False)
        self._qtgui_number_sink_0_win = sip.wrapinstance(self.qtgui_number_sink_0.pyqwidget(), Qt.QWidget)
        self.aba_layout_4.addWidget(self._qtgui_number_sink_0_win)
        self.qtgui_const_sink_x_0 = qtgui.const_sink_c(
        	1024, #size
        	"", #name
        	2 #number of inputs
        )
        self.qtgui_const_sink_x_0.set_update_time(0.10)
        self.qtgui_const_sink_x_0.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_0.enable_autoscale(False)
        self.qtgui_const_sink_x_0.enable_grid(False)
        
        if not True:
          self.qtgui_const_sink_x_0.disable_legend()
        
        labels = ["", "", "", "", "",
                  "", "", "", "", ""]
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
                  "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(2):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_0.set_line_alpha(i, alphas[i])
        
        self._qtgui_const_sink_x_0_win = sip.wrapinstance(self.qtgui_const_sink_x_0.pyqwidget(), Qt.QWidget)
        self.aba_layout_3.addWidget(self._qtgui_const_sink_x_0_win)
        self.low_pass_filter_0_0 = filter.fir_filter_fff(1, firdes.low_pass(
        	1, samp_rate, Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.low_pass_filter_0 = filter.fir_filter_fff(1, firdes.low_pass(
        	1, samp_rate, Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.dc_blocker_xx_0 = filter.dc_blocker_ff(400, True)
        self.blocks_vco_c_0 = blocks.vco_c(samp_rate, 2*3.14159265359*kf, 1)
        self.blocks_throttle_1 = blocks.throttle(gr.sizeof_gr_complex*1, samp_rate,True)
        self.blocks_throttle_0 = blocks.throttle(gr.sizeof_gr_complex*1, samp_rate,True)
        self.blocks_sub_xx_0_0 = blocks.sub_ff(1)
        self.blocks_sub_xx_0 = blocks.sub_ff(1)
        self.blocks_rms_xx_1_1_0 = blocks.rms_ff(0.0001)
        self.blocks_rms_xx_1_1 = blocks.rms_ff(0.0001)
        self.blocks_rms_xx_1_0_0 = blocks.rms_ff(0.0001)
        self.blocks_rms_xx_1_0 = blocks.rms_ff(0.0001)
        self.blocks_rms_xx_1 = blocks.rms_ff(0.0001)
        self.blocks_rms_xx_0_1 = blocks.rms_cf(0.0001)
        self.blocks_rms_xx_0_0_0 = blocks.rms_cf(0.0001)
        self.blocks_rms_xx_0_0 = blocks.rms_ff(0.0001)
        self.blocks_rms_xx_0 = blocks.rms_ff(0.0001)
        self.blocks_null_sink_0_2_0 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_2 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0 = blocks.null_sink(gr.sizeof_gr_complex*1)
        self.blocks_nlog10_ff_3_0_0 = blocks.nlog10_ff(1, 1, 0)
        self.blocks_nlog10_ff_3 = blocks.nlog10_ff(1, 1, 0)
        self.blocks_nlog10_ff_2_0_0 = blocks.nlog10_ff(1, 1, 0)
        self.blocks_nlog10_ff_2 = blocks.nlog10_ff(1, 1, 0)
        self.blocks_nlog10_ff_1 = blocks.nlog10_ff(1, 1, 0)
        self.blocks_nlog10_ff_0 = blocks.nlog10_ff(1, 1, 0)
        self.blocks_multiply_xx_1 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0 = blocks.multiply_vff(1)
        self.blocks_multiply_const_vxx_2 = blocks.multiply_const_vff((1/(2*3.14159265359*kf/samp_rate), ))
        self.blocks_multiply_const_vxx_1 = blocks.multiply_const_vff((output_gain, ))
        self.blocks_multiply_const_vxx_0_0 = blocks.multiply_const_vff((An_AM, ))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_vcc((An_FM, ))
        self.blocks_float_to_complex_1 = blocks.float_to_complex(1)
        self.blocks_float_to_complex_0 = blocks.float_to_complex(1)
        self.blocks_divide_xx_1_0 = blocks.divide_ff(1)
        self.blocks_divide_xx_1 = blocks.divide_ff(1)
        self.blocks_divide_xx_0_0 = blocks.divide_ff(1)
        self.blocks_divide_xx_0 = blocks.divide_ff(1)
        self.blocks_delay_0_2 = blocks.delay(gr.sizeof_float*1, 378)
        self.blocks_delay_0 = blocks.delay(gr.sizeof_float*1, 393)
        self.blocks_complex_to_real_2 = blocks.complex_to_real(1)
        self.blocks_complex_to_real_1 = blocks.complex_to_real(1)
        self.blocks_complex_to_real_0 = blocks.complex_to_real(1)
        self.blocks_add_xx_1 = blocks.add_vcc(1)
        self.blocks_add_xx_0 = blocks.add_vff(1)
        self.blocks_add_const_vxx_1 = blocks.add_const_vff((-2*3.14159265359*fc/samp_rate, ))
        self.blocks_add_const_vxx_0 = blocks.add_const_vff((1, ))
        self.blocks_abs_xx_0 = blocks.abs_ff(1)
        self.band_pass_filter_1_0 = filter.fir_filter_ccf(1, firdes.band_pass(
        	1, samp_rate, fc-(2*Bm + 2*Df)/2, fc+(2*Bm + 2*Df)/2, 100, firdes.WIN_HAMMING, 6.76))
        self.band_pass_filter_1 = filter.fir_filter_fff(1, firdes.band_pass(
        	1, samp_rate, fc-Bm, fc+Bm, 100, firdes.WIN_HAMMING, 6.76))
        self.band_pass_filter_0 = filter.fir_filter_fff(1, firdes.band_pass(
        	1, samp_rate, 100, Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.analog_sig_source_x_1 = analog.sig_source_c(samp_rate, analog.GR_COS_WAVE, fc, 1, 0)
        self.analog_sig_source_x_0 = analog.sig_source_f(samp_rate, analog.GR_TRI_WAVE, fm, 2*Am, -Am/2)
        self.analog_pll_freqdet_cf_0 = analog.pll_freqdet_cf(3.14159265359/50, 2*3.14159265359*(fc+Df+Bm)/samp_rate, 2*3.14159265359*(fc-Df-Bm)/samp_rate)
        self.analog_noise_source_x_0 = analog.noise_source_c(analog.GR_GAUSSIAN, 1, 0)

        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_noise_source_x_0, 0), (self.blocks_complex_to_real_0, 0))    
        self.connect((self.analog_noise_source_x_0, 0), (self.blocks_multiply_const_vxx_0, 0))    
        self.connect((self.analog_noise_source_x_0, 0), (self.blocks_throttle_0, 0))    
        self.connect((self.analog_pll_freqdet_cf_0, 0), (self.blocks_add_const_vxx_1, 0))    
        self.connect((self.analog_sig_source_x_0, 0), (self.band_pass_filter_0, 0))    
        self.connect((self.analog_sig_source_x_1, 0), (self.blocks_complex_to_real_2, 0))    
        self.connect((self.analog_sig_source_x_1, 0), (self.blocks_throttle_1, 0))    
        self.connect((self.band_pass_filter_0, 0), (self.blocks_add_const_vxx_0, 0))    
        self.connect((self.band_pass_filter_0, 0), (self.blocks_rms_xx_1, 0))    
        self.connect((self.band_pass_filter_0, 0), (self.blocks_sub_xx_0, 1))    
        self.connect((self.band_pass_filter_0, 0), (self.blocks_sub_xx_0_0, 1))    
        self.connect((self.band_pass_filter_0, 0), (self.blocks_vco_c_0, 0))    
        self.connect((self.band_pass_filter_0, 0), (self.qtgui_time_sink_x_0, 2))    
        self.connect((self.band_pass_filter_1, 0), (self.blocks_add_xx_0, 0))    
        self.connect((self.band_pass_filter_1, 0), (self.blocks_rms_xx_0, 0))    
        self.connect((self.band_pass_filter_1_0, 0), (self.blocks_add_xx_1, 0))    
        self.connect((self.band_pass_filter_1_0, 0), (self.blocks_rms_xx_0_1, 0))    
        self.connect((self.blocks_abs_xx_0, 0), (self.low_pass_filter_0, 0))    
        self.connect((self.blocks_add_const_vxx_0, 0), (self.blocks_multiply_xx_0, 0))    
        self.connect((self.blocks_add_const_vxx_1, 0), (self.blocks_multiply_const_vxx_2, 0))    
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_abs_xx_0, 0))    
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_null_sink_0_2, 0))    
        self.connect((self.blocks_add_xx_1, 0), (self.analog_pll_freqdet_cf_0, 0))    
        self.connect((self.blocks_add_xx_1, 0), (self.blocks_complex_to_real_1, 0))    
        self.connect((self.blocks_complex_to_real_0, 0), (self.blocks_multiply_const_vxx_0_0, 0))    
        self.connect((self.blocks_complex_to_real_1, 0), (self.blocks_null_sink_0_2_0, 0))    
        self.connect((self.blocks_complex_to_real_2, 0), (self.blocks_multiply_xx_0, 1))    
        self.connect((self.blocks_delay_0, 0), (self.blocks_sub_xx_0, 0))    
        self.connect((self.blocks_delay_0, 0), (self.qtgui_time_sink_x_0, 0))    
        self.connect((self.blocks_delay_0_2, 0), (self.blocks_sub_xx_0_0, 0))    
        self.connect((self.blocks_delay_0_2, 0), (self.qtgui_time_sink_x_0, 1))    
        self.connect((self.blocks_divide_xx_0, 0), (self.blocks_nlog10_ff_0, 0))    
        self.connect((self.blocks_divide_xx_0_0, 0), (self.blocks_nlog10_ff_1, 0))    
        self.connect((self.blocks_divide_xx_1, 0), (self.blocks_nlog10_ff_2, 0))    
        self.connect((self.blocks_divide_xx_1_0, 0), (self.blocks_nlog10_ff_3, 0))    
        self.connect((self.blocks_float_to_complex_0, 0), (self.qtgui_const_sink_x_0, 0))    
        self.connect((self.blocks_float_to_complex_1, 0), (self.qtgui_const_sink_x_0, 1))    
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.band_pass_filter_1_0, 0))    
        self.connect((self.blocks_multiply_const_vxx_0_0, 0), (self.band_pass_filter_1, 0))    
        self.connect((self.blocks_multiply_const_vxx_1, 0), (self.blocks_delay_0, 0))    
        self.connect((self.blocks_multiply_const_vxx_1, 0), (self.blocks_rms_xx_1_0_0, 0))    
        self.connect((self.blocks_multiply_const_vxx_2, 0), (self.low_pass_filter_0_0, 0))    
        self.connect((self.blocks_multiply_xx_0, 0), (self.blocks_add_xx_0, 1))    
        self.connect((self.blocks_multiply_xx_0, 0), (self.blocks_rms_xx_0_0, 0))    
        self.connect((self.blocks_multiply_xx_1, 0), (self.blocks_add_xx_1, 1))    
        self.connect((self.blocks_multiply_xx_1, 0), (self.blocks_rms_xx_0_0_0, 0))    
        self.connect((self.blocks_nlog10_ff_0, 0), (self.blocks_float_to_complex_1, 0))    
        self.connect((self.blocks_nlog10_ff_0, 0), (self.qtgui_time_sink_x_1_0, 0))    
        self.connect((self.blocks_nlog10_ff_1, 0), (self.blocks_float_to_complex_0, 0))    
        self.connect((self.blocks_nlog10_ff_1, 0), (self.qtgui_time_sink_x_1_0, 1))    
        self.connect((self.blocks_nlog10_ff_2, 0), (self.blocks_float_to_complex_1, 1))    
        self.connect((self.blocks_nlog10_ff_2, 0), (self.qtgui_time_sink_x_1, 0))    
        self.connect((self.blocks_nlog10_ff_2_0_0, 0), (self.qtgui_number_sink_0, 0))    
        self.connect((self.blocks_nlog10_ff_3, 0), (self.blocks_float_to_complex_0, 1))    
        self.connect((self.blocks_nlog10_ff_3, 0), (self.qtgui_time_sink_x_1, 1))    
        self.connect((self.blocks_nlog10_ff_3_0_0, 0), (self.qtgui_number_sink_0, 1))    
        self.connect((self.blocks_rms_xx_0, 0), (self.blocks_divide_xx_0, 1))    
        self.connect((self.blocks_rms_xx_0_0, 0), (self.blocks_divide_xx_0, 0))    
        self.connect((self.blocks_rms_xx_0_0_0, 0), (self.blocks_divide_xx_0_0, 0))    
        self.connect((self.blocks_rms_xx_0_1, 0), (self.blocks_divide_xx_0_0, 1))    
        self.connect((self.blocks_rms_xx_1, 0), (self.blocks_divide_xx_1, 0))    
        self.connect((self.blocks_rms_xx_1, 0), (self.blocks_divide_xx_1_0, 0))    
        self.connect((self.blocks_rms_xx_1_0, 0), (self.blocks_divide_xx_1, 1))    
        self.connect((self.blocks_rms_xx_1_0_0, 0), (self.blocks_nlog10_ff_2_0_0, 0))    
        self.connect((self.blocks_rms_xx_1_1, 0), (self.blocks_divide_xx_1_0, 1))    
        self.connect((self.blocks_rms_xx_1_1_0, 0), (self.blocks_nlog10_ff_3_0_0, 0))    
        self.connect((self.blocks_sub_xx_0, 0), (self.blocks_rms_xx_1_0, 0))    
        self.connect((self.blocks_sub_xx_0_0, 0), (self.blocks_rms_xx_1_1, 0))    
        self.connect((self.blocks_throttle_0, 0), (self.blocks_null_sink_0, 0))    
        self.connect((self.blocks_throttle_1, 0), (self.blocks_multiply_xx_1, 1))    
        self.connect((self.blocks_vco_c_0, 0), (self.blocks_multiply_xx_1, 0))    
        self.connect((self.dc_blocker_xx_0, 0), (self.blocks_multiply_const_vxx_1, 0))    
        self.connect((self.low_pass_filter_0, 0), (self.dc_blocker_xx_0, 0))    
        self.connect((self.low_pass_filter_0_0, 0), (self.blocks_delay_0_2, 0))    
        self.connect((self.low_pass_filter_0_0, 0), (self.blocks_rms_xx_1_1_0, 0))    

    def closeEvent(self, event):
        self.settings = Qt.QSettings("GNU Radio", "top_block")
        self.settings.setValue("geometry", self.saveGeometry())
        event.accept()


    def get_kf(self):
        return self.kf

    def set_kf(self, kf):
        self.kf = kf
        self.set_Df(self.kf*self.Am)
        self.blocks_multiply_const_vxx_2.set_k((1/(2*3.14159265359*self.kf/self.samp_rate), ))

    def get_Am(self):
        return self.Am

    def set_Am(self, Am):
        self.Am = Am
        self.set_Df(self.kf*self.Am)
        self.analog_sig_source_x_0.set_amplitude(2*self.Am)
        self.analog_sig_source_x_0.set_offset(-self.Am/2)

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.analog_pll_freqdet_cf_0.set_max_freq(2*3.14159265359*(self.fc+self.Df+self.Bm)/self.samp_rate)
        self.analog_pll_freqdet_cf_0.set_min_freq(2*3.14159265359*(self.fc-self.Df-self.Bm)/self.samp_rate)
        self.analog_sig_source_x_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_1.set_sampling_freq(self.samp_rate)
        self.band_pass_filter_0.set_taps(firdes.band_pass(1, self.samp_rate, 100, self.Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.band_pass_filter_1.set_taps(firdes.band_pass(1, self.samp_rate, self.fc-self.Bm, self.fc+self.Bm, 100, firdes.WIN_HAMMING, 6.76))
        self.band_pass_filter_1_0.set_taps(firdes.band_pass(1, self.samp_rate, self.fc-(2*self.Bm + 2*self.Df)/2, self.fc+(2*self.Bm + 2*self.Df)/2, 100, firdes.WIN_HAMMING, 6.76))
        self.blocks_add_const_vxx_1.set_k((-2*3.14159265359*self.fc/self.samp_rate, ))
        self.blocks_multiply_const_vxx_2.set_k((1/(2*3.14159265359*self.kf/self.samp_rate), ))
        self.blocks_throttle_0.set_sample_rate(self.samp_rate)
        self.blocks_throttle_1.set_sample_rate(self.samp_rate)
        self.low_pass_filter_0.set_taps(firdes.low_pass(1, self.samp_rate, self.Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.low_pass_filter_0_0.set_taps(firdes.low_pass(1, self.samp_rate, self.Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.qtgui_time_sink_x_0.set_samp_rate(self.samp_rate)
        self.qtgui_time_sink_x_1.set_samp_rate(self.samp_rate)
        self.qtgui_time_sink_x_1_0.set_samp_rate(self.samp_rate)

    def get_output_gain(self):
        return self.output_gain

    def set_output_gain(self, output_gain):
        self.output_gain = output_gain
        self.blocks_multiply_const_vxx_1.set_k((self.output_gain, ))

    def get_fm(self):
        return self.fm

    def set_fm(self, fm):
        self.fm = fm
        self.analog_sig_source_x_0.set_frequency(self.fm)

    def get_fc(self):
        return self.fc

    def set_fc(self, fc):
        self.fc = fc
        self.analog_pll_freqdet_cf_0.set_max_freq(2*3.14159265359*(self.fc+self.Df+self.Bm)/self.samp_rate)
        self.analog_pll_freqdet_cf_0.set_min_freq(2*3.14159265359*(self.fc-self.Df-self.Bm)/self.samp_rate)
        self.analog_sig_source_x_1.set_frequency(self.fc)
        self.band_pass_filter_1.set_taps(firdes.band_pass(1, self.samp_rate, self.fc-self.Bm, self.fc+self.Bm, 100, firdes.WIN_HAMMING, 6.76))
        self.band_pass_filter_1_0.set_taps(firdes.band_pass(1, self.samp_rate, self.fc-(2*self.Bm + 2*self.Df)/2, self.fc+(2*self.Bm + 2*self.Df)/2, 100, firdes.WIN_HAMMING, 6.76))
        self.blocks_add_const_vxx_1.set_k((-2*3.14159265359*self.fc/self.samp_rate, ))

    def get_Df(self):
        return self.Df

    def set_Df(self, Df):
        self.Df = Df
        self.analog_pll_freqdet_cf_0.set_max_freq(2*3.14159265359*(self.fc+self.Df+self.Bm)/self.samp_rate)
        self.analog_pll_freqdet_cf_0.set_min_freq(2*3.14159265359*(self.fc-self.Df-self.Bm)/self.samp_rate)
        self.band_pass_filter_1_0.set_taps(firdes.band_pass(1, self.samp_rate, self.fc-(2*self.Bm + 2*self.Df)/2, self.fc+(2*self.Bm + 2*self.Df)/2, 100, firdes.WIN_HAMMING, 6.76))

    def get_Bm(self):
        return self.Bm

    def set_Bm(self, Bm):
        self.Bm = Bm
        self.analog_pll_freqdet_cf_0.set_max_freq(2*3.14159265359*(self.fc+self.Df+self.Bm)/self.samp_rate)
        self.analog_pll_freqdet_cf_0.set_min_freq(2*3.14159265359*(self.fc-self.Df-self.Bm)/self.samp_rate)
        self.band_pass_filter_0.set_taps(firdes.band_pass(1, self.samp_rate, 100, self.Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.band_pass_filter_1.set_taps(firdes.band_pass(1, self.samp_rate, self.fc-self.Bm, self.fc+self.Bm, 100, firdes.WIN_HAMMING, 6.76))
        self.band_pass_filter_1_0.set_taps(firdes.band_pass(1, self.samp_rate, self.fc-(2*self.Bm + 2*self.Df)/2, self.fc+(2*self.Bm + 2*self.Df)/2, 100, firdes.WIN_HAMMING, 6.76))
        self.low_pass_filter_0.set_taps(firdes.low_pass(1, self.samp_rate, self.Bm+1000, 100, firdes.WIN_HAMMING, 6.76))
        self.low_pass_filter_0_0.set_taps(firdes.low_pass(1, self.samp_rate, self.Bm+1000, 100, firdes.WIN_HAMMING, 6.76))

    def get_An_FM(self):
        return self.An_FM

    def set_An_FM(self, An_FM):
        self.An_FM = An_FM
        self.blocks_multiply_const_vxx_0.set_k((self.An_FM, ))

    def get_An_AM(self):
        return self.An_AM

    def set_An_AM(self, An_AM):
        self.An_AM = An_AM
        self.blocks_multiply_const_vxx_0_0.set_k((self.An_AM, ))


def main(top_block_cls=top_block, options=None):

    from distutils.version import StrictVersion
    if StrictVersion(Qt.qVersion()) >= StrictVersion("4.5.0"):
        style = gr.prefs().get_string('qtgui', 'style', 'raster')
        Qt.QApplication.setGraphicsSystem(style)
    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()
    tb.start()
    tb.show()

    def quitting():
        tb.stop()
        tb.wait()
    qapp.connect(qapp, Qt.SIGNAL("aboutToQuit()"), quitting)
    qapp.exec_()


if __name__ == '__main__':
    main()
